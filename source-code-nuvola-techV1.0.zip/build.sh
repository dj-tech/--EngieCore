if-config
docker build . 
docker-compose up
