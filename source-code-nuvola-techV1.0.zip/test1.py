import os
import sys
a = open "r","docker-compose.yml"
print a
nuvola-tech = open "r","test.sh"
print nuvola-tech
